﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using clase_10.Models;
using Microsoft.EntityFrameworkCore;

namespace clase_10.Models.Data
{
    public class DBUniversidad:DbContext
    {
        public  DBUniversidad (DbContextOptions<DBUniversidad> db): base(db)
        {

        }
        public DbSet<Estudiante> estudiantes { get; set; }
    }
}

